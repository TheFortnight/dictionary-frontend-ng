export interface Word {
    word: string,
    id: number,
    language: string
}