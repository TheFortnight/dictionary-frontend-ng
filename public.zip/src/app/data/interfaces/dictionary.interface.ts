export interface Dictionary {
    id: number,
    name: string,
    author: string,
    year: number | null,
    language_id: number
}